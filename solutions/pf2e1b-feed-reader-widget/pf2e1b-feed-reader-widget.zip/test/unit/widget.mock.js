var Widget = module.exports = function Widget () {

};

Widget.prototype.getPreference = function() {}
Widget.prototype.setPreference = function() {}
